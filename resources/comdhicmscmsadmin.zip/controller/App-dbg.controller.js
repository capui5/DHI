sap.ui.define([
    "./BaseController",
    "sap/ui/core/Fragment"
  ], (BaseController,Fragment) => {
  "use strict";

  return BaseController.extend("com.dhi.cms.cmsadmin.controller.App", {
      onInit() {
      }
  });
});